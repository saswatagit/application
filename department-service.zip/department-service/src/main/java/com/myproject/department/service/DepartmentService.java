package com.myproject.department.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Service;

import com.myproject.department.controller.CustomException;
import com.myproject.department.customexception.ServiceException;
import com.myproject.department.entity.Department;
import com.myproject.department.repository.DepartmentRepositpory;

@Service
@Transactional

public class DepartmentService {

	@Autowired
	private DepartmentRepositpory departmentRepositpory;

	public List<Department> saveDepartment(ArrayList<Department> department) {

		
		return departmentRepositpory.saveAll(department);
	}

	/*
	 * public Department saveDepartment(Department department) {
	 * 
	 * return departmentRepositpory.save(department); }
	 */

	public Department getDepartment(Long departmentId) throws ServiceException {

		try {
		
			return departmentRepositpory.findByDepartmentId(departmentId);
	
		}
		catch(Exception e){
					
			throw new ServiceException("303","ID not found" + e.getMessage());
		}
		

	}	
	public List<Department> getAllDepartments() throws ServiceException {

						
			List<Department> departments = departmentRepositpory.findAll();
			if(departments.isEmpty()) {
				
			throw new ServiceException("301","List is empty");
			}
			try {
			return departments;
		}
		catch(Exception e){ 
			
			throw new ServiceException("302","Something went wrong fetching all departments" + e.getMessage());
		}
	}

	public Department updateDepartment(Department department, Long departmentId) {

		department.setDepartmentId(departmentId);
		return departmentRepositpory.save(department);
	}

	public void deleteDepartment(Long departmentId)  {
		
		//try {
			
			departmentRepositpory.deleteByDepartmentId(departmentId);
		//}	
		/*	catch(Exception e){
				
				throw new ServiceException("306","Something went wrong while deleting" + e.getMessage());
			}
		*/	
		
		

	}

}
