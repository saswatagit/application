package com.myproject.department.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.myproject.department.customexception.ControllerException;
import com.myproject.department.customexception.ServiceException;
import com.myproject.department.entity.Department;
import com.myproject.department.service.DepartmentService;

@RestController
@RequestMapping("/")

public class DepartmentController {

	@Autowired
	DepartmentService departmentService;
	
	Logger logger = LoggerFactory.getLogger(DepartmentController.class);

	
	
	@PostMapping("/departments/create")
	public List<Department> saveDepartment(@RequestBody ArrayList<Department> department) {

		logger.info("New resource created");

		return departmentService.saveDepartment(department);

	}

	/*
	 * @RequestMapping("/departments/create") public Department
	 * saveDepartment(@RequestBody Department department) {
	 * 
	 * 
	 * return departmentService.saveDepartment(department);
	 * 
	 * }
	 */

	@GetMapping("/departments/list/{id}")
	public Department getDepartment(@PathVariable("id") Long departmentId) throws ServiceException {

		logger.info("Get ID details");
		
			return departmentService.getDepartment(departmentId);
		
	}

	@GetMapping(value = "/departments/list")
	public @ResponseBody List<Department> getAllDepartments() throws ServiceException {

		logger.info("Get list");
		return departmentService.getAllDepartments();
	}

	@PutMapping("/departments/update/{id}")
	public Department updateDepartment(@RequestBody Department department, @PathVariable("id") Long departmentId) {

		logger.info("Get updated id details");

		return departmentService.updateDepartment(department, departmentId);

	}

	@DeleteMapping("/departments/delete/{id}")
	public void deleteDepartment(@PathVariable("id") Long departmentId)
			throws ServiceException {

		logger.info("Delete ID");

		departmentService.deleteDepartment(departmentId);

	}

}
