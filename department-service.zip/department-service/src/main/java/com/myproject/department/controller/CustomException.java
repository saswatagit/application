package com.myproject.department.controller;

public class CustomException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CustomException() {
		
		super("Function is not working");
	}
}
