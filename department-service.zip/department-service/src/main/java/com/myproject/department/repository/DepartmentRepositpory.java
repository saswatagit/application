package com.myproject.department.repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.hibernate.metamodel.model.convert.spi.JpaAttributeConverter;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.myproject.department.entity.Department;

@Repository
public interface DepartmentRepositpory extends JpaRepository<Department, Long> {

	
	
	Department findByDepartmentId(Long departmentId);
	
	
	Department deleteByDepartmentId(Long departmentId);

}
